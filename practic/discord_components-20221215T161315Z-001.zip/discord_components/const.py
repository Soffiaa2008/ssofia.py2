"""Discord Components Constants"""

__version__ = "2.1.2"
